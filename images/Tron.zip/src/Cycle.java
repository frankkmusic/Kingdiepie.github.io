import java.awt.Color;
import java.awt.Graphics2D;

public class Cycle {

	private int xPos, yPos, sideLength, speed, direction, boost, baseSpeed,
			flyynScore, starkScore, nitro;
	private Color color;

	public Cycle() {
		xPos = 0;
		yPos = 0;
		sideLength = 0;
		speed = 0;
		color = null;
		direction = 0;
		boost = 0;
	}

	public Cycle(int xVal, int yVal, int dirVal, Color colVal) {
		xPos = xVal;
		yPos = yVal;
		sideLength = 6;
		baseSpeed = 4;
		speed = 4;
		color = colVal;
		direction = dirVal;
		boost = 14;
		nitro = 5;
	}

	public void boost() {
		if (speed == baseSpeed && nitro > 0)
			speed = boost;	
			nitro--;  
	}

	public void speed() {
		if (speed > baseSpeed)
			speed--;
	}


	public void draw(Graphics2D g) {
		g.setColor(color);
		g.fillRect(xPos, yPos, sideLength, sideLength);

	}

	public void updatePos() {
		if (direction == 0)
			xPos += speed;
		else if (direction == 180)
			xPos -= speed;
		else if (direction == 90)
			yPos -= speed;
		else
			yPos += speed;

	}

	public int getDirection() {
		return direction;
	}

	public void setDirection(int d) {
		direction = d;
	}

	public boolean willDie() {
		if (direction == 0 && !TronGame.isWhite(xPos + sideLength + 1, yPos)) {
			return true;
		} else if (direction == 180 && !TronGame.isWhite(xPos - 1, yPos)) {
			return true;
		} else if (direction == 90 && !TronGame.isWhite(xPos, yPos - 1)) {
			return true;
		} else if (direction == 270
				&& !TronGame.isWhite(xPos, yPos + sideLength + 1)) {
			return true;
		} else
			return false;
	}
}