import java.applet.Applet;
import java.applet.AudioClip;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.*;


public class TronGame extends JPanel implements KeyListener, ActionListener {

  // YOUR CODE GOES HERE...
  // declare all instance variables (i.e. fields) here

  private int frameCount;// used for the score
  private static String title = "~~ Tron Light Cycles ~~  "
      + "CONTROLS: Flynn(BLUE): Arrow keys and \']\' .. Sark(RED): RDFG keys and- \'Q\' .. \'6\' to start";
  public Timer timer;// handles animation
  private static Image offScreenBuffer;// needed for double buffering graphics
  private Graphics offScreenGraphics;// needed for double buffering graphics
  private Cycle flynn = new Cycle();
  private Cycle sark = new Cycle();
  private boolean flynnwin = false;
  private boolean sarkwin = false;
  private int flynnScore = 0;
  private int sarkScore = 0;
  
  
  /**
   * main() is needed to initialize the window.<br>
   * THIS METHOD SHOULD NOT BE MODIFIED! .. <br>
   * you should write all necessary initialization code in initRound()
   */
  public static void main(String[] args) {
    JFrame window = new JFrame("Tron");
    window.setBounds(0, 0, 1280, 972);// almost 1280x1024 window
    window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    window.setResizable(false);

    TronGame game = new TronGame();
    window.getContentPane().add(game);
    window.setBackground(Color.BLACK);
    window.setVisible(true);
    game.init();
    window.addKeyListener(game);
  }
  
  /**
   * init method needed to initialize non-static fields<br>
   * THIS METHOD SHOULD NOT BE MODIFIED! ..
   */
  public void init() {
    offScreenBuffer = createImage(getWidth(), getHeight());// should be 1016x736
    offScreenGraphics = offScreenBuffer.getGraphics();
    timer = new Timer(20, this);
    // timer fires every 20 milliseconds.. invokes method actionPerformed()
    initRound();
    
  }
  
  /**
   * initializes all fields needed for each round of play (i.e. restart)
   */
  public void initRound() {
    frameCount = 0;
    offScreenGraphics.clearRect(0, 0, 1280, 972);
    flynnwin = false;
    sarkwin = false;
    repaint();
    flynn = new Cycle(1080,450,180,Color.BLUE);
    sark = new Cycle(100,450,0,Color.RED);
    // YOUR CODE GOES HERE..
    // initialize instance variables here for each round of play
  }
  
  /**
   * Called automatically after a repaint request<br>
   * THIS METHOD SHOULD NOT BE MODIFIED! ..
   */
  public void paint(Graphics g) {
    draw((Graphics2D) offScreenGraphics);
    g.drawImage(offScreenBuffer, 0, 0, this);
  }

  /**
   * renders all objects to Graphics g
   */
  public void draw(Graphics2D g) {
    g.setColor(Color.BLACK);
    sark.draw(g);
    flynn.draw(g);
    if (flynnwin == true){
    	g.setColor(Color.BLUE);
    	g.setFont(new Font("TimesRoman", Font.PLAIN, 20));
    	g.drawString("Flyyn Wins, score of:" + sarkScore + " to " + flynnScore, 1030, 25);
    }
    if (sarkwin == true) {
    	g.setColor(Color.RED);
    	g.setFont(new Font("TimesRoman", Font.PLAIN, 20));
    	g.drawString("Sark Wins, score of:" + sarkScore + " to " + flynnScore , 25, 25);
    }
    
  }
  /**
   * Called automatically when the timer fires<br>
   * this is where all the game fields will be updated
   */
  public void actionPerformed(ActionEvent e) {

    // YOUR CODE GOES HERE..
    // update all game Objects here
	flynn.updatePos();
	sark.updatePos();
	if (flynn.willDie() == true){
		timer.stop();
		sarkwin = true;
		flynnScore++;
	}
	if (sark.willDie() == true){
		timer.stop();
		flynnwin = true;
		sarkScore++;
	}
    frameCount++;// update the frameCount
    repaint();// needed to refresh the animation
    int clock = 0;
    if (clock % 5 == 0) {
    	flynn.speed();
    	sark.speed();
  }
  clock ++;  
  }
    
    
  
  
  /**
   * handles any key pressed events and updates the Cycle's direction by setting
   * their direction to either 0,90,180 or 270 based on which key is pressed.
   */
  public void keyPressed(KeyEvent e) {
    int keyCode = e.getKeyCode();
    if (keyCode == KeyEvent.VK_LEFT) {
      flynn.setDirection(180);
    } else if (keyCode == KeyEvent.VK_RIGHT) {
      flynn.setDirection(0);
    } else if (keyCode == KeyEvent.VK_DOWN) {
        flynn.setDirection(270);
    } else if (keyCode == KeyEvent.VK_UP) {
        flynn.setDirection(90);
    } else if (keyCode == KeyEvent.VK_CLOSE_BRACKET) {
    	flynn.boost();
    }
    if (keyCode == KeyEvent.VK_R) {
        sark.setDirection(90);
    } else if (keyCode == KeyEvent.VK_F) {
        sark.setDirection(270);
    } else if (keyCode == KeyEvent.VK_D) {
        sark.setDirection(180);
    } else if (keyCode == KeyEvent.VK_G) {
        sark.setDirection(0);
    } else if (keyCode == KeyEvent.VK_Q) {
        sark.boost();
    }
  }
  /**
   * handles any key released events ... <br>
   * starts game by the '6 Key'<br>
   * kills the game window by the 'Escape Key'
   */
  public void keyReleased(KeyEvent e) {
    int keyCode = e.getKeyCode();
    if (keyCode == KeyEvent.VK_6) {
      // start the game .. if the game has not currently running
      if (!timer.isRunning()) {
        timer.start();
        initRound();
      }
    } else if (keyCode == KeyEvent.VK_ESCAPE) {
      // kill game process... close the window
      System.exit(0);
    }
  }
  
  /**
   * this method is needed for implementing interface KeyListener<br>
   * THIS METHOD SHOULD NOT BE MODIFIED! ..
   */
  public void keyTyped(KeyEvent e) {
  }
  
  /**
   * returns true if the color value of the pixel<br>
   * with coordinates (x,y) is WHITE, false otherwise<br>
   * NOTE: THIS METHOD SHOULD NOT BE MODIFIED!!!
   */
  public static boolean isWhite(int x, int y) {
    BufferedImage bi = (BufferedImage) offScreenBuffer;
    if (bi == null)
      return true;
    try {
      int colorVal = bi.getRGB(x, y);
      return (colorVal == -16777216);
    } catch (Exception ex) {
      return false;
    }
  }
}// end class TronGame


